package com.example.ejemplosPerfilesPostgre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplosPerfilesPostgreApplicationTests {

	@Test
	void contextLoads() {
	}

}
