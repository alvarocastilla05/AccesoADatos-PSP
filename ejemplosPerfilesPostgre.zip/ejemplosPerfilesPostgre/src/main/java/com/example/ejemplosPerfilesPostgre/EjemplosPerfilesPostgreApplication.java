package com.example.ejemplosPerfilesPostgre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemplosPerfilesPostgreApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemplosPerfilesPostgreApplication.class, args);
	}

}
