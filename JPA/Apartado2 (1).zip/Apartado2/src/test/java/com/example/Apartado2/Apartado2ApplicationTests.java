package com.example.Apartado2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apartado2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
