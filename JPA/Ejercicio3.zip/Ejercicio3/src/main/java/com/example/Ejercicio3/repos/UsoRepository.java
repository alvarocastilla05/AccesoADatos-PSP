package com.example.Ejercicio3.repos;

import com.example.Ejercicio3.model.Uso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsoRepository extends JpaRepository<Uso, Long> {
}
