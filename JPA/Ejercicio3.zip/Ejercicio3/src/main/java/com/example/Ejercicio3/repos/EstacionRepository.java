package com.example.Ejercicio3.repos;

import com.example.Ejercicio3.model.Estacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstacionRepository extends JpaRepository<Estacion, Long> {
}
