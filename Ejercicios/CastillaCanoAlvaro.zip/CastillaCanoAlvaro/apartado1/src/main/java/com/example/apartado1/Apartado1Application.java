package com.example.apartado1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apartado1Application {

	public static void main(String[] args) {
		SpringApplication.run(Apartado1Application.class, args);
	}

}
