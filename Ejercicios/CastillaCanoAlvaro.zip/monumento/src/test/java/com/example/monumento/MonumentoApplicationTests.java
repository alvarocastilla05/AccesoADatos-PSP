package com.example.monumento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonumentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
